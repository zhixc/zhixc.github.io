SKIPMOUNT=false
#安装后开关
PROPFILE=false
#system.prop文件
POSTFSDATA=false
#post-fs-data脚本
LATESTARTSERVICE=false
#service.sh中脚本
print_modname() {
  ui_print "*******************************"
  ui_print "      MIUI拦截广告   "
  ui_print "    作者酷安ID枫落流昔"
  ui_print "    方法提供者@上之湖水"
}
on_install() {
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  ui_print "- 安装完毕，开始清理碎片"
    /dev/*/.magisk/busybox/fstrim -v /cache 
    rm -rf /data/system/package_cache/*
  ui_print "-安装完成"
}

set_permissions() {
  set_perm_recursive  $MODPATH  0  0  0755  0644
}