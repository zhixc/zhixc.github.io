SKIPMOUNT=false
key_source(){
if [[ -e "$1" ]];then
source "$1"
rm -rf "$1"
fi
}
key_source $MODPATH/key.sh
key_source $MODPATH/check.sh
key_source $MODPATH/lite_function.sh
key_source $MODPATH/update.sh
key_source $MODPATH/uniq.sh
rm -rf /data/system/package_cache/*
rm -rf /data/data/com.android.thememanager/cache/*

