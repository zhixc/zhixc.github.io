#!/system/bin/sh

function appinfo() {
chmod -R 0755 $MODPATH/tools
local appname="${1}"
$MODPATH/tools/appinfo -d " " -o ands -pn "$appname"
}

function show_value() {
	local value=$1
	local file=${MODPATH}/升级系统应用操作.prop
	cat "$file" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g'
}

function trimmer_file() {
	local file=$1
	sed -i '/^[[:space:]]*$/d' ${file}
	oldfile=$(sort -n ${file} | uniq)
	echo "$oldfile" >${file}
}

function correctpath() {
	case $(echo "${1}") in
	/system_ext* | /vendor* | /product*)
		echo "/system"${1}""
		;;
	/system*)
		echo "${1}"
		;;
	esac
}

function recovery_app_path() {
	local package=$1
	dumpsys package $package | grep -w "codePath=" | sed "/\/data/d;s|.*codePath=||g"
}

function kill_update_app() {
	local package=$1
	if test $(show_value "操作") == 卸载 ; then
		pm uninstall --user 0 $package >/dev/null 2>&1
		echo "$package" >>${MODPATH}/卸载包名.conf
	elif test $(show_value "操作") == 冻结 ; then
		pm disable $package >/dev/null 2>&1
		echo "$package" >>${MODPATH}/冻结包名.conf
	fi
}

function lite_app_in_naturely() {
local file="${1}"
test "$(cat "${file}" | sed '/^#/d;/^[[:space:]]*$/d')" = "" && return 1
cat "${file}" | sed "/^\#/d;/^[[:space:]]*$/d" | while read appname; do
		app_path="$(pm path $appname | sed 's|package:||g')"
		system_path="$(correctpath $app_path)"
		data_path="$(recovery_app_path $appname)"
		correct_data_path="$(correctpath ${data_path})"
case $app_path in
/system* | /system_ext* | /vendor* | /product*)
cat << key

※应用名称：$(appinfo "$appname")※
※安装路径：${system_path}
key
			mktouch "$MODPATH${system_path%/*}/.replace"
		echo -e "\n#$(appinfo "$appname")\n${system_path}" >> ${MODPATH}/精简路径.conf
	echo -n "[ $(appinfo "$appname") ]" >> $MODPATH/litename.log
;;
/data*)
cat << key

※应用名称：$(appinfo "$appname")※
※安装路径：${app_path} ※
※原本的系统安装路径：${correct_data_path}※
※您选择操作方式：$(show_value "操作")
key
				mktouch "$MODPATH${correct_data_path%/*}/.replace"
			echo -e "\n#$(appinfo "$appname")\n${correct_data_path}" >> ${MODPATH}/精简路径.conf
		echo -n "[ $(appinfo "$appname") ]" >> $MODPATH/litename.log
	kill_update_app $appname
;;
esac
done
}

function system_app_cache() {
	folder="${1}"
	find "$folder/system" -iname "*app" -type d 2>/dev/null | grep -v 'overlay' | while read app; do
		find $app -type d -maxdepth 1 2>/dev/null | while read dir; do
			app_dir=${dir##*/}
			test $app_dir = "priv-app" && continue
			test $app_dir = "app" && continue
			cat <<key >>${folder}/uninstall.sh
rm -rf /data/dalvik-cache/*/system@*@${app_dir}* 2>/dev/null
rm -rf /data/system/package_cache/* 2>/dev/null
key
		done && sed -i "1i #!/system/bin/sh\n#清理系统应用的缓存" ${folder}/uninstall.sh
		trimmer_file ${folder}/uninstall.sh
	done
}

function overlay_cache() {
	folder="${1}"
	find "$folder/system" -iname "*overlay" -type d 2>/dev/null | while read app; do
		find $app -type d -maxdepth 1 2>/dev/null | while read dir; do
			overlay_file=${dir##*/}
			test "$overlay_file" = "overlay" && continue
			cat <<key >>${folder}/uninstall.sh
rm -rf /data/resource-cache/*@${overlay_file}* 2>/dev/null
rm -rf /data/system/package_cache/* 2>/dev/null
key
		done && sed -i "1i #!/system/bin/sh\n#清理overlay应用的缓存" ${folder}/uninstall.sh
	trimmer_file ${folder}/uninstall.sh
	done
}

function write_litename() {
local file=$MODPATH/module.prop
if test -e $file ;then
sed -i "/^description\=/d" $file
	echo -e "\ndescription=自用MIUI精简，请了解下安卓的pm命令，以及magisk精简的原理，不然你就等着变砖吧。已精简：$(echo -n $(cat $MODPATH/litename.log))" >> $file
sed -i "/^[[:space:]]*$/d" $file
fi
}

function delete(){
	rm -rf $MODPATH/tools $MODPATH/升级系统应用操作.conf $MODPATH/litename.log
}





#开始精简
echo ""
echo "●————————————————◎"
echo ""
echo "- ※开始精简※"
for file in $MODPATH/精简名单/*.prop
do
prop_size="$(du -k $file | awk '{print $1}' | tr -cd '[0-9]'  )"
prop_details="$(cat $file 2>/dev/null | sed '/^#/d;/^[[:space:]]*$/d;s/[[:space:]]//g;s|/n||g' )"
if test -f "$file" -a "$prop_size" -ge "1" -a "$prop_details" != "" ;then
	lite_app_in_naturely "$file"
fi
done
echo ""
echo "●————————————————◎"
#保留上次精简
key_source $MODPATH/update.sh
#生成卸载脚本
system_app_cache $MODPATH
overlay_cache $MODPATH
write_litename
delete

