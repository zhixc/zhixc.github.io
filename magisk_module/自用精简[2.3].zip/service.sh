#!/system/bin/sh
MODDIR=${0%/*}

for i in $(cat $MODDIR/disable.conf | uniq );do
pm disable "$i" >/dev/null 2>&1 && echo ""$i"已成功冻结" || echo ""$i"冻结失败！"
done