rm -rf /data/system/package_cache/*
rm -rf /data/data/com.android.thememanager/cache/*
rm -rf /data/system/users/0/package-restrictions.xml


