file="
$MODPATH/disable.conf
$MODPATH/disablepath.log
$MODPATH/uninstall.sh
"



for i in $file;do
file=`cat $i | uniq | sed '/^[:space:]*$/d'`
	echo "$file" > $i
done


