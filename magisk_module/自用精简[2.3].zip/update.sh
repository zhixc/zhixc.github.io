id="$id"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
KeyMODPATH="/data/adb/$Magisk_mod/$id"
lite_path_file=$KeyMODPATH/精简路径.conf
uninstall_package_name=$KeyMODPATH/卸载包名.conf
freeze_package_name=$KeyMODPATH/冻结包名.conf


function update_mod_(){
echo ""
echo "◎—————保留模块原本的精简—————●"
echo ""
if test -e $lite_path_file ;then
	for i in $(cat $lite_path_file | sed '/^#/d;/^[[:space:]]*$/d' | sort | uniq );do
		mktouch $MODPATH${i%/*}/.replace && echo "- ※精简路径：${i%/*}/.replace ※"
	done
fi
echo ""
echo "●————————————————◎"
echo ""
}

function trimmer_file() {
	local file=$1
	if test -e $file ;then
	sed -i '/^[[:space:]]*$/d' ${file}
	oldfile=$(sort -n ${file} | uniq)
	echo "$oldfile" >${file}
	fi
}

local IFS=$'\n'
list="
$freeze_package_name
$uninstall_package_name
$lite_path_file
"
for i in $list
do
if test -e "$i" ;then
cat $i >> "$MODPATH/${i##*/}"
trimmer_file "$MODPATH/${i##*/}"
fi
done


test -e "$lite_path_file" && update_mod_

